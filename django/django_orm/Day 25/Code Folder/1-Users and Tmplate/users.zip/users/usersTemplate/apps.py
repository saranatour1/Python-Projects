from django.apps import AppConfig


class UserstemplateConfig(AppConfig):
    name = 'usersTemplate'
